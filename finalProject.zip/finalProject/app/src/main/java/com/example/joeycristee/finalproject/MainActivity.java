package com.example.joeycristee.finalproject;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private ImageView wheel;
    private TextView colorBar;
    private TextView rgbText;
    private Bitmap bitmap;
    private ImageView selector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        wheel = (ImageView) findViewById(R.id.colorWheel);
        selector = (ImageView) findViewById(R.id.selector);
        colorBar = (TextView) findViewById(R.id.textView);
        rgbText = (TextView) findViewById(R.id.rgbText);

//Adapted From https://stackoverflow.com/questions/16939380/how-do-i-get-color-of-where-i-click?noredirect=1&lq=1
        wheel.setDrawingCacheEnabled(true);
        wheel.buildDrawingCache(true);
        wheel.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {

                int xAbsolute = (int) event.getRawX();
                int yAbsolute = (int) event.getRawY();

                int x = selector.getLeft();
                int x2= selector.getRight();
                int xOffset= (x2- x)/2;

                int y = selector.getTop();
                int y2= selector.getBottom();
                int yOffset= (y2-y)/2;

                float xrel =  event.getX() -xOffset;
                float yrel =  event.getY() -yOffset;

                bitmap = wheel.getDrawingCache();
                int pixel = bitmap.getPixel((int) event.getX(), (int) event.getY());

                Log.d("loc", xAbsolute + " " + yAbsolute);
                Log.d("loc2", xrel + " " + yrel);

                int red = Color.red(pixel);
                int green = Color.green(pixel);
                int blue = Color.blue(pixel);

                String rgb = red + ", " + green + ", " + blue;
                Log.d("rgb", rgb);

                colorBar.setBackgroundColor(Color.rgb(red,green,blue));
                rgbText.setText("RGB: " + rgb);
                moveSelector(selector, xrel, yrel);

                return false;
            }
        });

    }

//    private View.OnTouchListener handleTouch = new View.OnTouchListener() {
//        @Override
//        public boolean onTouch(View v, MotionEvent event) {
//
//            int x = (int) event.getX();
//            int y = (int) event.getY();
//            return false;
//        }
//    }


    public void moveSelector(View view, float xMove, float yMove){
        view.animate().x(xMove).y(yMove).setDuration(100);
    }
}





package com.example.joeycristee.lab7;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {
    private sportSite userSportSite = new sportSite();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findSport(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    private void findSport(View view){
        String userChoice;
        RadioGroup sport = findViewById(R.id.RadioGroup);
        int sportChecked = sport.getCheckedRadioButtonId();

        if(sportChecked == R.id.nba){
            userChoice = "nba";
        }
        else if(sportChecked == R.id.nfl){
            userChoice = "nfl";
        }
        else{
            userChoice = "mlb";
        }

        userSportSite.setSport(userChoice);
        String chosenSport = userSportSite.getSport();
        String chosenURL = userSportSite.getSportURL();
        Log.i("sport",chosenSport);
        Log.i("url",chosenURL);

        Intent intent = new Intent(this, ReceiveSportActivity.class);
        intent.putExtra("sportName",chosenSport);
        intent.putExtra("sportURL",chosenURL);

        startActivity(intent);
    }
}

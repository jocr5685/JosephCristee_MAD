package com.example.joeycristee.lab7;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveSportActivity extends AppCompatActivity {

    private String sport;
    private String sportURL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_sport);
        Intent intent = getIntent();
        sport = intent.getStringExtra("sportName");
        sportURL = intent.getStringExtra("sportURL");
        Log.i("sport received", sport);
        Log.i("url received", sportURL);

        TextView messageView = findViewById(R.id.sportTextView);
        messageView.setText("Your favorite " + sport + " gear can be found at the website below." );

        Button button2 = findViewById(R.id.button2);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };
        button2.setOnClickListener(onclick);
    }

    private void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(sportURL));
        startActivity(intent);
    }
}

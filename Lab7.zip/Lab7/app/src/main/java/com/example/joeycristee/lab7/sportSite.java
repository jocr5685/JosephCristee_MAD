package com.example.joeycristee.lab7;

public class sportSite {
    private String sport;
    private String sportURL;


    private void sportChoice(String userChoice) {
        if (userChoice == "nba") {
            sport = "NBA";
            sportURL = "https://www.nba.com/";
        } else if (userChoice == "nfl") {
            sport = "NFL";
            sportURL = "https://www.nfl.com/";
        } else {
            sport = "MLB";
            sportURL = "https://www.mlb.com/";
        }
    }

    public void setSport(String userChoice){
        sportChoice(userChoice);
    }
    public void setSportURL(String userChoice){
        sportChoice(userChoice);
    }

    public String getSport(){
        return sport;
    }
    public String getSportURL(){
        return sportURL;
    }


}
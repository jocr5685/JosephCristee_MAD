package com.example.joeycristee.la5;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sayGoodMorning(View view){
        TextView gmText = findViewById(R.id.output);
        EditText name = findViewById(R.id.editText);
        String inputName = name.getText().toString();
        gmText.setText("Good Morning " + inputName);
        ImageView pic = findViewById(R.id.imageView4);
        pic.setImageResource(R.drawable.morning);
    }
}

package com.example.joeycristee.finalcristee;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceivePizzaActivity extends AppCompatActivity {
    private String pizzaShop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_pizza);
        Intent intent = getIntent();
        pizzaShop = intent.getStringExtra("pizzaShopName");

        TextView messageView = findViewById(R.id.suggestedPizza);
        messageView.setText("You should check out " + pizzaShop);
    }
}

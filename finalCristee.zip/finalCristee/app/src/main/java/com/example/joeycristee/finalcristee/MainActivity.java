package com.example.joeycristee.finalcristee;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private pizzaShop myPizzaShop = new pizzaShop();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button2);
        //create listener
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findPizza(view);
            }
        };
        //add listener to the button
        button.setOnClickListener(onclick);
    }

    public void createPizza(View view) {

        EditText pizzaName = findViewById(R.id.editText);
        String inPizza = pizzaName.getText().toString();

        Spinner size = findViewById(R.id.spinner);

        String pizzaSize = String.valueOf(size.getSelectedItem());
        String finalSize = "";

        switch(pizzaSize){
            case "Small":
                finalSize="Small";
                break;
            case "Medium":
                finalSize="Medium";
                break;
            case "Large":
                finalSize="Large";
                break;
            default:
                finalSize="";
        }

        String crustChoice="";
        RadioGroup crust = findViewById(R.id.radioGroup);
        int crustChecked = crust.getCheckedRadioButtonId();

        if(crustChecked==-1){
            Context context = getApplicationContext();
            CharSequence text = "Please select a crust type";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        }
        else {
            if (crustChecked == R.id.thin) {
                crustChoice = "thin";
            } else {
                crustChoice = "thick";
            }
            TextView pizzaSelection = findViewById(R.id.pizzaDescription);
            pizzaSelection.setText("The " + inPizza + " is a " +finalSize+ " " + crustChoice + " crust pizza");
        }

    }

    private void findPizza(View view){
        Spinner sizeAgain = findViewById(R.id.spinner);
        Integer sizeOfPizza = sizeAgain.getSelectedItemPosition();
        myPizzaShop.setPizzaShop(sizeOfPizza);
        String suggestedPizza = myPizzaShop.getPizzaShop();
        Log.i("shop", suggestedPizza);

        Intent intent = new Intent(this, ReceivePizzaActivity.class);

        //pass data
        intent.putExtra("pizzaShopName", suggestedPizza);
        startActivity(intent);
    }
}

package com.example.joeycristee.finalcristee;

public class pizzaShop {
    private String pizzaShop;

    private void setPizzaInfo(Integer sizeOfPizza) {
        switch (sizeOfPizza) {
            case 0:
                pizzaShop = "Pizzeria Locale";
                break;
            case 1:
                pizzaShop = "Old Chicago";
                break;
            case 2:
                pizzaShop = "Boss lady";
                break;
            default:
                pizzaShop = "none";
        }
    }

    public void setPizzaShop(Integer sizeOfPizza){
        setPizzaInfo(sizeOfPizza);
    }

    public String getPizzaShop(){
        return pizzaShop;
    }

}

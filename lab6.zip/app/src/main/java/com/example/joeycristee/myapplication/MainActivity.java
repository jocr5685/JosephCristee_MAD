package com.example.joeycristee.myapplication;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void madLib(View view){

        ToggleButton hideShow = findViewById(R.id.toggleButton);
        boolean toggleResult = hideShow.isChecked();

        EditText name=findViewById(R.id.editText);
        String inName = name.getText().toString();

        String verbChoice="";
        RadioGroup verb = findViewById(R.id.radioGroup);
        int verbChecked = verb.getCheckedRadioButtonId();

        if(verbChecked==-1){
            Context context = getApplicationContext();
            CharSequence text = "Please select a verb";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        }
        else {
            if (verbChecked == R.id.radioButton1) {
                verbChoice = "runs";
            } else {
                verbChoice = "walks";
            }
        }

        String finalNoun="";
        Spinner noun = findViewById(R.id.spinner);
        String nounChoice = String.valueOf(noun.getSelectedItem());

        switch(nounChoice){
            case "gas station":
                finalNoun="gas station";
                break;
            case "office":
                finalNoun="office";
                break;
            case "store":
                finalNoun="store";
                break;
            default:
                finalNoun="";
        }

        String adverbFinal = "";

        CheckBox often = findViewById(R.id.checkBox);
        Boolean oftenState = often.isChecked();

        CheckBox never = findViewById(R.id.checkBox2);
        Boolean neverState = never.isChecked();

        CheckBox sometimes = findViewById(R.id.checkBox3);
        Boolean sometimeState = sometimes.isChecked();

        if(oftenState){
            adverbFinal = "often";
        }
        else if (neverState){
            adverbFinal = "never";
        }
        else if (sometimeState){
            adverbFinal = "sometimes";
        }
        else{
            adverbFinal = "";
        }


        TextView finalText = findViewById(R.id.finalSentence);
        if(toggleResult) {
            finalText.setText(inName + " " + verbChoice + " to the " + finalNoun + " " + adverbFinal);
        }
        else{
            finalText.setText("");
        }

    }
}
